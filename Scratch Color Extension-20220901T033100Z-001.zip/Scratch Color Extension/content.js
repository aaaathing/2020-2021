chrome.runtime.sendMessage({colorCurrentTab:true}, function(response) {

});