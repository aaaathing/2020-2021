//please copy all and paste in console at https://minekhan.thingmaker.repl.co/

/*
  html for world name:
  <div style="position:absolute;top:0;left:0;width:100vw;height:100vh;background:yellow;"><a href="https://www.thingmaker.repl.co">COOL</a></div>
*/

var p = player

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms))
}
function fill(x,y,z,x2,y2,z2, blockID){
  if(x>x2){var px=x; x=x2; x2=px}
  if(y>y2){var py=y; y=y2; y2=py}
  if(z>z2){var pz=z; z=z2; z2=pz}
  for(var X=x; x2>=X; X++){
    for(var Y=y; y2>=Y; Y++){
      for(var Z=z; z2>=Z; Z++){
        world.setBlock(X,Y,Z,blockID)
      }
    }
  }
}
var copiedBlocks = [];
function copy(x,y,z,x2,y2,z2){
  if(x>x2){var px=x; x=x2; x2=px}
  if(y>y2){var py=y; y=y2; y2=py}
  if(z>z2){var pz=z; z=z2; z2=pz}
  
  copiedBlocks = [];
  for(var X=x; x2>=X; X++){
    var xRow = [];
    for(var Y=y; y2>=Y; Y++){
      var yRow = []
      for(var Z=z; z2>=Z; Z++){
        yRow.push(world.getBlock(X,Y,Z));
      }
      xRow.push(yRow);
    }
    copiedBlocks.push(xRow);
  }
}
function paste(x,y,z){
  for(var X = 0; X<copiedBlocks.length; X++){
    var xRow = copiedBlocks[X];
    for(var Y=0; Y<xRow.length; Y++){
      var yRow = xRow[Y];
      for(var Z=0; Z<yRow.length; Z++){
        var block = yRow[Z];
        world.setBlock(X+x,Y+y,Z+z,block)
      }
    }
  }
}

/*//{ for willard.fun
async function clickMouse(x,y,z,x2,y2,z2,button, invertY){
  for(var i=3; i>0; i--){
    console.log(i)
    await sleep(1000)
  }
  var lookDown = p.rx=-Math.PI/2
  
  if(x>x2){var px=x; x=x2; x2=px}
  if(y>y2){var py=y; y=y2; y2=py}
  if(z>z2){var pz=z; z=z2; z2=pz}
  async function eachBlock(X,Y,Z){
    p.y = Y+1
    p.x = X
    p.z = Z
    p.flying = true
    await sleep(100)
    p.rx = lookDown
    canvas.onmousedown({button:button})
    canvas.onmouseup({button:button})
  }
  if(invertY){
    for(var X=x; x2>=X; X++){
      for(var Y=y2; Y>y; Y--){
        for(var Z=z; z2>=Z; Z++){
          await eachBlock(X,Y,Z)
        }
      }
    }
  }else{
    for(var X=x; x2>=X; X++){
      for(var Y=y; y2>=Y; Y++){
        for(var Z=z; z2>=Z; Z++){
          await eachBlock(X,Y,Z)
        }
      }
    }
  }
  p.x = x2
  p.y = y
  p.z = z2
}
function digGroundToPlayer(){
  clickMouse(prevPos[0], prevPos[1], prevPos[2], p2.x, prevPos[1], p2.z, 0)
}
function placeGroundToPlayer(){
  clickMouse(prevPos[0], prevPos[1], prevPos[2], p2.x, prevPos[1], p2.z, 2)
}
function placeBoxToPlayer(){
  clickMouse(prevPos[0], prevPos[1], prevPos[2], p2.x, p2.y, p2.z, 2)
}
function digBoxToPlayer(){
  clickMouse(prevPos[0], prevPos[1], prevPos[2], p2.x, p2.y, p2.z, 0, true)
}
//}*/

var prevPos;
function fromPlayer(){
  prevPos = [p2.x, p2.y, p2.z]
}
function fillToPlayer(id){
  //fills at player feet
  fill(prevPos[0], prevPos[1]-1, prevPos[2], p2.x, p2.y-1, p2.z, id)
}

function copyToPlayer(){
  copy(prevPos[0], prevPos[1]-1, prevPos[2], p2.x, p2.y-1, p2.z);
}
function pasteAtPlayer(){
  paste(p2.x,p2.y-1,p2.z)
}
function preserveToPlayer(){
  var x=p2.x, y=p2.y, z=p2.z,
      x2=prevPos[0], y2=prevPos[1]-1, z2=prevPos[2]
  if(x>x2){var px=x; x=x2; x2=px}
  if(y>y2){var py=y; y=y2; y2=py}
  if(z>z2){var pz=z; z=z2; z2=pz}
  for(var X=x; x2>=X; X++){
    for(var Y=y; y2>=Y; Y++){
      for(var Z=z; z2>=Z; Z++){
        world.setBlock(X,Y,Z,world.getBlock(X,Y,Z))
      }
    }
  }
}

function hcyl(bottom, height, radius, id) {
    let radsq = radius * radius
    let innerRadsq = (radius - 1.2) * (radius - 1.2)
    height += bottom
    for (let x = -radius; x <= radius; x++) {
        for (let y = bottom; y < height; y++) {
            for (let z = -radius; z <= radius; z++) {
                let d = x * x + z * z
                if (d < radsq && d >= innerRadsq) {
                    world.setBlock(p2.x + x, p2.y + y, p2.z + z, id)
                }
            }
        }
    }
}

function cyl(bottom, height, radius, id) {
    let radsq = radius * radius
    height += bottom
    for (let x = -radius; x <= radius; x++) {
        for (let y = bottom; y < height; y++) {
            for (let z = -radius; z <= radius; z++) {
                let d = x * x + z * z
                if (d < radsq) {
                    world.setBlock(p2.x + x, p2.y + y, p2.z + z, id)
                }
            }
        }
    }
}

function sphereoid(w, h, d, id) {
    let w2 = w * w
    let h2 = h * h
    let d2 = d * d
    let w3 = (w - 1.5) * (w - 1.5)
    let h3 = (h - 1.5) * (h - 1.5)
    let d3 = (d - 1.5) * (d - 1.5)

    for (let y = -h; y < h; y++) {
        for (let x = -w; x <= w; x++) {
            for (let z = -d; z <= d; z++) {
                let n = x * x / w2 + y * y / h2 + z * z / d2
                let n2 = x * x / w3 + y * y / h3 + z * z / d3
                if (n < 1 && n2 >= 1) {
                    world.setBlock(p2.x + x, p2.y + y, p2.z + z, id)
                }
            }
        }
    }
}

function sphereoidAt(X,Y,Z,w, h, d, id) {
    let w2 = w * w
    let h2 = h * h
    let d2 = d * d
    let w3 = (w - 1.5) * (w - 1.5)
    let h3 = (h - 1.5) * (h - 1.5)
    let d3 = (d - 1.5) * (d - 1.5)

    for (let y = -h; y < h; y++) {
        for (let x = -w; x <= w; x++) {
            for (let z = -d; z <= d; z++) {
                let n = x * x / w2 + y * y / h2 + z * z / d2
                let n2 = x * x / w3 + y * y / h3 + z * z / d3
                if (n < 1 && n2 >= 1) {
                    world.setBlock(X + x, Y + y, Z + z, id)
                }
            }
        }
    }
}

function blockTxt(txt, block, bgBlock){
block = block || block === 0 ? block : blockIds.glowstone;
bgBlock = bgBlock || 0;
var chars = {
  A:[
      "11111",
      "1---1",
      "11111",
      "1---1",
      "1---1"
    ],
  B:[
      "1111 ",
      "1---1",
      "1111 ",
      "1---1",
      "1111 "
    ],
  C:[
      " 1111",
      "1",
      "1",
      "1",
      " 1111"
    ],
  D:[
      "1111 ",
      "1---1",
      "1---1",
      "1---1",
      "1111"
    ],
  E:[
      "11111",
      "1",
      "11111",
      "1",
      "11111"
    ],
  F:[
      "11111",
      "1",
      "11111",
      "1",
      "1"
    ],
  G:[
      "11111",
      "1",
      "1--11",
      "1---1",
      "11111"
    ],
  H:[
      "1---1",
      "1---1",
      "11111",
      "1---1",
      "1---1"
    ],
  I:[
      "111",
      "-1",
      "-1",
      "-1",
      "111"
    ],
  J:[
      "11111",
      "---1",
      "---1",
      "1--1",
      "1111"
    ],
  K:[
      "1---1",
      "1--1",
      "111",
      "1--1",
      "1---1"
    ],
  L:[
      "1",
      "1",
      "1",
      "1",
      "11111"
    ],
  M:[
      "11111",
      "1-1-1",
      "1-1-1",
      "1-1-1",
      "1-1-1"
    ],
  N:[
      "1---1",
      "11--1",
      "1-1-1",
      "1--11",
      "1---1"
    ],
  O:[
      "11111",
      "1---1",
      "1---1",
      "1---1",
      "11111"
    ],
  P:[
      '11111',
      "1---1",
      "11111",
      "1",
      "1"
    ],
  Q:[
      "11111",
      "1---1",
      "1---1",
      "1--11",
      "11111",
      "-----1"
    ],
  R:[
      "11111",
      "1---1",
      "11111",
      "1--1",
      "1---1"
    ],
  S:[
      "11111",
      "1",
      "11111",
      "----1",
      "11111"
    ],
  T:[
      "11111",
      "--1",
      "--1",
      "--1",
      "--1"
    ],
  U:[
      "1---1",
      "1---1",
      "1---1",
      "1---1",
      "11111"
    ],
  V:[
      "1---1",
      "1---1",
      "-1-1",
      "-1-1",
      "--1"
    ],
  W:[
      "1-1-1",
      "1-1-1",
      "1-1-1",
      "1-1-1",
      "11111"
    ],
  X:[
      "1---1",
      "-1-1",
      "--1",
      "-1-1",
      "1---1"
    ],
  Y:[
      "1---1",
      "-1-1",
      "--1",
      "--1",
      "--1"
    ],
  Z:[
      "11111",
      "---1",
      "--1",
      "-1",
      "11111"
    ],
  a:[
      "-111",
      "----1",
      "-1111",
      "1---1",
      "-1111"
    ],
  b:[
      "1",
      "1",
      "1111",
      "1---1",
      "1111"
    ],
  c:[
      "",
      "-1111",
      "1",
      "1",
      "-1111"
    ],
  d:[
      "----1",
      "----1",
      "-1111",
      "1---1",
      "-1111"
    ],
  e:[
      "-111",
      "1---1",
      "11111",
      "1",
      "-1111"
    ],
  f:[
      "--111",
      "-1",
      "11111",
      "-1",
      "-1"
    ],
  g:[
      "",
      "-111",
      "1---1",
      "-1111",
      "----1",
      "-111"
    ],
  h:[
      "1",
      "1",
      "1111",
      "1---1",
      "1---1"
    ],
  i:[
      "",
      "1",
      "",
      "1",
      "1"
    ],
  j:[
      "---1",
      "",
      "---1",
      "1--1",
      "-11"
    ],
  k:[
      "1",
      "1-1",
      "11",
      "1-1",
      "1--1"
    ],
  l:[
      "1",
      "1",
      "1",
      "1",
      "1"
    ],
  m:[
      "",
      "",
      "1111",
      "1-1-1",
      "1-1-1"
    ],
  n:[
      "",
      "1-11",
      "11--1",
      "1---1",
      "1---1"
    ],
  o:[
      "",
      "-111",
      "1---1",
      "1---1",
      "-111"
    ],
  p:[
      "",
      "1111",
      "1---1",
      "1111",
      "1"
    ],
  q:[
      "",
      "-1111",
      "1---1",
      "-1111",
      "----1"
    ],
  r:[
      "",
      "",
      "1-111",
      "11",
      "1"
    ],
  s:[
      "-111",
      "1",
      "-111",
      "----1",
      "-111"
    ],
  t:[
      "",
      "-1",
      "111",
      "-1",
      "-11"
    ],
  u:[
      "",
      "",
      "1---1",
      "1---1",
      "-1111"
    ],
  v:[
      "",
      "",
      "1---1",
      "-1-1",
      "--1"
    ],
  w:[
      "",
      "",
      "1-1-1",
      "1-1-1",
      "-1-1"
    ],
  x:[
      "",
      "",
      "1--1",
      "-11",
      "1--1"
    ],
  y:[
      "",
      "1---1",
      "-1-1",
      "--1",
      "11-"
    ],
  z:[
      "",
      "1111",
      "--1",
      "-1",
      "1111"
    ],
  1:[
      "-11",
      "1-1",
      "--1",
      "--1",
      "11111"
    ],
  2:[
      "1111",
      "----1",
      "--11",
      "-1",
      "11111"
    ],
  3:[
      "1111",
      "----1",
      "1111",
      "----1",
      "1111"
    ],
  4:[
      "1--1",
      "1--1",
      "11111",
      "---1",
      "---1"
    ],
  5:[
      "11111",
      "1",
      "1111",
      "----1",
      "1111"
    ],
  6:[
      "-111",
      "1",
      "1111 ",
      "1---1",
      "-111"
    ],
  7:[
      "11111",
      "---1",
      "--1",
      "-1",
      "1"
    ],
  8:[
      "-111",
      "1---1",
      "-111",
      "1---1",
      "-111"
    ],
  9:[
      "-111",
      "1---1",
      "-1111",
      "----1",
      "-111"
    ],
  0:[
      "-111",
      "1---1",
      "1---1",
      "1---1",
      "-111"
    ],
  "~":[
        "-1-1",
        "1-1"
      ],
  "`":[
      "1",
      "-1"
      ],
  "!":[
        "1",
        "1",
        "1",
        "",
        "1"
      ],
  "@":[
        "11111",
        "1---1",
        "1-111",
        "1-1-1",
        "11111"
      ],
  "#":[
        "-1-1",
        "11111",
        "-1-1",
        "11111",
        "-1-1"
      ],
  "$":[
        "11111",
        "1-1",
        "11111",
        "--1-1",
        "11111"
      ],
  "%":[
        "----1",
        "1--1",
        "--1",
        "-1--1",
        "1"
      ],
  "^":[
        "--1",
        "-1-1",
        "-1-1"
      ],
  "&":[
      "-1",
      "1-1",
      "-11-1",
      "1--1",
      "-11-1"
    ],
  "*":[
        "--1",
        "-111",
        "--1-",
        "-1-1",
      ],
  "(":[
        "--1",
        "-1",
        "-1",
        "-1",
        "--1"
      ],
  ")":[
        "--1",
        "---1",
        "---1",
        "---1",
        "--1"
      ],
  "-":[
        "",
        "",
        "111"
      ],
  "_":[
        "",
        "",
        "",
        "",
        "11111"
      ],
  "=":[
        "",
        "-111",
        "",
        "-111"
      ],
  "+":[
        "",
        "--1",
        "-111",
        "--1"
      ],
  "[":[
        "-11",
        "-1",
        "-1",
        "-1",
        "-11"
      ],
  "]":[
        "--11",
        "---1",
        "---1",
        "---1",
        "--11"
      ],
  "{":[
        "--11",
        "--1",
        "-1",
        "--1",
        "--11"
      ],
  "}":[
        "-11",
        "--1",
        "---1",
        "--1",
        "-11"
      ],
  "|":[
        "-1",
        "-1",
        "-1",
        "-1",
        "-1"
      ],
  ":":[
        "",
        "1",
        "",
        "1"
      ],
  ";":[
        "",
        "1",
        "",
        "1",
        "1"
      ],
  "'":[
        "--1",
        "--1"
      ],
  '"':[
        "-1-1",
        "-1-1"
      ],
  "<":[
        "--1",
        "-1",
        "1",
        "-1",
        "--1"
      ],
  ">":[
        "1",
        "-1",
        "--1",
        "-1",
        "1"
      ],
  ",":[
        "",
        "",
        "",
        "",
        "-1",
        "1",
      ],
  ".":[
        "",
        "",
        "",
        "",
        "1"
      ],
  "/":[
        "---1",
        "--1",
        "--1",
        "-1",
        "-1"
      ],
  "\\":[
        "-1",
        "--1",
        "--1",
        "---1",
        "---1"
      ],
  "?":[
        "-111",
        "1---1",
        "--11",
        "",
        "--1"
      ],
};
var charLens = {
  I:4,
  i:2,
  l:2,
  t:4,
  x:5,
  z:5,
  " ":3,
  "-":4,
  "!":2,
  ".":2,
  ",":3,
  "|":3,
  "<":4,
  ">":4,
  ":":2,
  ";":2,
};
  function char(c,cx,cy,cz,block,bgBlock){
    if(!chars[c]){return}
    c = chars[c];
    for(var y=0;y<c.length;y++){
      var row=c[y];
      for(var x=0;x<row.length;x++){
        if(row[x]==="1"){
          world.setBlock(cx+x, cy-y,cz,block);
        }else if(bgBlock){
          world.setBlock(cx+x, cy-y,cz,bgBlock);
        }
      }
    }
  }

  var x = 0, y = 0;
  for(var i=0; i<txt.length; i++){
    if(txt[i] === "\n"){
      x = 0;
      y += 6;
    }else{
      char(txt[i], p2.x+x, p2.y+y,p2.z, block, bgBlock);
      x += charLens[txt[i]] || 6;
    }
  }
};
cmds.push({
  name:"blockTxt",
  info:"Writes text with blocks. The block argument is the block used to write it",
  args: ["text","block"],
  func: split => {
    if(!split[1]) return
    let id = blockIds[split[2]]
    if(!split[2]) id = 1
    blockTxt(split[1], id)
  }
})

/*var getPixels = function(str) {
  var colors = []
  var pixels = []
  var dCount = 0
  for (;str[4 + dCount] === "0"; dCount++) {}
  var ccount = parseInt(str.substr(4+dCount, dCount+1), 36)
  for (var i = 0; i < ccount; i++) {
    var num = parseInt(str.substr(5 + 2*dCount + i * 7, 7), 36)
    colors.push([ num >>> 24 & 255, num >>> 16 & 255, num >>> 8 & 255, num & 255 ])
  }
  for (let i = 5 + 2*dCount + ccount * 7; i < str.length; i++) {
    let num = parseInt(str[i], 36)
    pixels.push(colors[num][0], colors[num][1], colors[num][2], colors[num][3])
  }
  return pixels
};*/
const base256CharSet = '0123456789abcdefghijklmnopqrstuvwxyzABCDEF!#$%&L(MNO)*+,-./:;<=WSTR>Q?@[]P^_{|}~ÀÁÂÃUVÄÅÆÇÈÉÊËÌÍKÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãGäåæçèéêHëìíîXïðñIòóôõö÷øùúJûüýþÿĀāĂăĄąĆćĈĉĊċČčĎďĐđĒēĔĕĖėĘęĚěĜĝĞğĠġĢģĤĥĦYħĨĩĪīĬĭĮįİıĲĳĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŒœŔŕŖŗŘřŚśŜŝŞşŠšŢţŤťZ'
const base256DecodeMap = new Map()
for (let i = 0; i < 256; i++) base256DecodeMap.set(base256CharSet[i], i)
function decodeByte(str) {
  let num = 0
  for (let char of str) {
    num <<= 8
    num += base256DecodeMap.get(char)
  }
  return num
}
var getPixels = function(str, r = 255, g = 255, b = 255) {
  const width = decodeByte(str.substr(0, 2))
  const height = decodeByte(str.substr(2, 2))
  const colorCount = decodeByte(str.substr(4, 1))
  const colors = []
  const pixels = new Uint8ClampedArray(width * height * 4)
  let pixi = 0

  for (let i = 0; i < colorCount; i++) {
    const num = decodeByte(str.substr(5 + i * 3, 3))

    let alpha = (num & 63) << 2
    let blue  = (num >>> 6 & 63) << 2
    let green = (num >>> 12 & 63) << 2
    let red   = (num >>> 18 & 63) << 2
    if (alpha >= 240) alpha = 255 // Make sure we didn't accidentally make the texture transparent

    if (red === blue && red === green) {
      red = red / 252 * r | 0
      green = green / 252 * g | 0
      blue = blue / 252 * b | 0
    }
    colors.push([ red, green, blue, alpha ])
  }

  // Special case for a texture filled with 1 pixel color
  if (colorCount === 1) {
    while (pixi < pixels.length) {
      pixels[pixi + 0] = colors[0][0]
      pixels[pixi + 1] = colors[0][1]
      pixels[pixi + 2] = colors[0][2]
      pixels[pixi + 3] = colors[0][3]
      pixi += 4
    }
    return pixels
  }

  let bytes = []
  for (let i = 5 + colorCount * 3; i < str.length; i++) { // Load the bit-packed index array
    const byte = decodeByte(str[i])
    bytes.push(byte)
  }

  const bits = Math.ceil(Math.log2(colorCount))
  const bitMask = (1 << bits) - 1
  let filledBits = 8
  let byte = bytes.shift()
  while (bytes.length || filledBits) {
    let num = 0
    if (filledBits >= bits) { // The entire number is inside the byte
      num = byte >> (filledBits - bits) & bitMask
      if (filledBits === bits && bytes.length) {
        byte = bytes.shift()
        filledBits = 8
      }
      else filledBits -= bits
    }
    else {
      num = byte << (bits - filledBits) & bitMask // Only part of the number is in the byte
      byte = bytes.shift() // Load in the next byte
      num |= byte >> (8 - bits + filledBits) // Apply the rest of the number from this byte
      filledBits += 8 - bits
    }

    pixels[pixi + 0] = colors[num][0]
    pixels[pixi + 1] = colors[num][1]
    pixels[pixi + 2] = colors[num][2]
    pixels[pixi + 3] = colors[num][3]
    pixi += 4
  }
  return pixels
}
var averageColors = []
var tempCanv = document.createElement("canvas")
tempCanv.width = tempCanv.height = 16
var tempCtx = tempCanv.getContext("2d")
for(var b = 1; b<BLOCK_COUNT; b++){
  var obj = blockData[b]
  var tex = textures[obj.textures[2]]
  if(typeof tex === "string" && obj.shape === shapes.cube && obj.onupdate === emptyFunc && !obj.transparent && !obj.item && !obj.edible){
    var pix = getPixels(tex)
    var trans
    for(var i=0; i<pix.length; i+=4){
      tempCtx.fillStyle = `rgba(${pix[i]},${pix[i+1]},${pix[i+2]},${pix[i+3]})`
      tempCtx.fillRect(i >> 2 & 15, i >> 6, 1,1)
    }
    tempCtx.drawImage(tempCanv, 0,0,1,1)
    var col = tempCtx.getImageData(0, 0, 1, 1).data
    averageColors[obj.id] = col
  }
}
function average(a,b,c,d){
  return (a+b+c+d) / 4
}
function wait(ms){
  return new Promise(resolve => setTimeout(() => resolve(), ms))
}
var abs = Math.abs
var image = new Image()
var imageRes = 1
image.onload = async function(){
  console.log("Rendering image...")
  var px = p2.x, py = p2.y, pz = p2.z
  tempCanv.width = image.width / imageRes, tempCanv.height = image.height / imageRes
  tempCtx.fillStyle = "white"
  tempCtx.fillRect(0,0, tempCanv.width,tempCanv.height)
  tempCtx.drawImage(image, 0,0, tempCanv.width,tempCanv.height)
  var pix = tempCtx.getImageData(0, 0, tempCanv.width,tempCanv.height).data
  if(blockImg.data_debug) console.log(pix)
  var x = -1, y = 0
  for(var i=0; i<pix.length; i+=4){
    var r = pix[i], g = pix[i+1], b = pix[i+2], a = pix[1+3]
    x ++
    if(x >= tempCanv.width){x = 0; y++}
    if(!a) continue
    //find closest color
    var closest
    var dist = Infinity
    for(var c=0; c<averageColors.length; c++){
      if(!averageColors[c]) continue
      var col = averageColors[c]
      var d = average(abs(col[0]-r), abs(col[1]-g), abs(col[2]-b), abs(col[3]-a))
      if(d < dist){
        dist = d
        closest = c
      }
    }
    try{
      world.setBlock(px+x, py+(tempCanv.height-y), pz, closest)
    }catch(e){
      console.log(e)
    }
    await wait(blockImg.data_speed)
  }
  console.log("Image done!")
}
function blockImg(url, res, debug, speed){
  console.log("Loading image...")
  imageRes = res || 1
  image.src = url
  image.crossOrigin = ""
  blockImg.data_debug = debug
  blockImg.data_speed = speed || 100
}
cmds.push({
  name:"blockImg",
  info:"Draws images with blocks.",
  args:["url", "resolution"],
  func: split => {
    blockImg(split[1], parseInt(split[2]))
  }
})
//do this image: https://i.ibb.co/mDMXP6x/i | oh it doesn't have cors
//this one works: https://i.imgur.com/ZbfRdP0l.png

//moving inventory item
/*
var i=JSON.parse(
"[{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":2,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":2,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":4,\"amount\":6},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":2},{\"id\":238,\"amount\":1},{\"id\":2,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":4,\"amount\":6},{\"id\":4,\"amount\":6},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":4,\"amount\":6},{\"id\":147,\"amount\":1},{\"id\":4,\"amount\":6},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":4,\"amount\":6},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":4},{\"id\":4,\"amount\":6},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":2,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":238,\"amount\":2},{\"id\":4,\"amount\":6},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":2,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":2},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":147,\"amount\":1},{\"id\":4,\"amount\":6},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":2},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":4,\"amount\":6},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":2},{\"id\":2,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":2},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":7},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":9,\"amount\":64},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":238,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1},{\"id\":147,\"amount\":1}]")
inventory.space.splice(0,inventory.space.length)
for(var j=0; j<i.length;j++) inventory.space[j] = i[j]
var keys = {}
canvas.addEventListener("keydown", e => {
  keys[e.key] = true
})
canvas.addEventListener("keyup", e => {
  keys[e.key] = false
})
var item = {x:0,y:0,s:inventory.size,moved:false}
item.y = item.x = item.s*1/4
function moveItem(x,y){
  item.x += item.s * x
  item.y += item.s * y
  item.moved = true
}
function loop(){
  item.moved = false
  if(keys.ArrowLeft) moveItem(-1,0)
  if(keys.ArrowRight) moveItem(1,0)
  if(keys.ArrowUp) moveItem(0,-1)
  if(keys.ArrowDown) moveItem(0,1)
  if(item.moved){
    document.onmousemove(item)
  }
}
setInterval(loop,1000)
*/

//Panorama generator
var pan = {
  rotY:0,
  w:innerWidth,
  h:innerHeight,
  c:document.createElement("canvas"),
  res:0.25,
  a:document.createElement("a"),
  download: function(){
    this.a.href = this.c.toDataURL()
    this.a.download = ""
    this.a.click()
  }
}
pan.ctx = pan.c.getContext("2d")
addEventListener("resize",()=>{pan.w=innerWidth; pan.h=innerHeight})
function panorama(){
  if(getScene() !== "pause") return console.log("Please have a active world and pause")
  console.log("Preparing...")
  pan.rotY = -pan.res //a bit less then 0
  pan.c.width = 360 / pan.res
  pan.c.height = pan.h
  console.log("Rendering...")
  var i = setInterval(function(){
    pan.rotY += pan.res
    var isDone = false
    if(pan.rotY > 361){
      isDone = true
    }
    var rotY = pan.rotY * Math.PI / 180
    player.rx = 0
    player.ry = rotY
    player.setDirection()
    world.render()
    pan.ctx.drawImage(gl.canvas, (pan.w/2)-1,0,1,pan.h, (pan.rotY-1) / pan.res,0,1,pan.h)
    var done = Math.floor((pan.rotY / 360 * 100)*100)/100
    ctx.fillStyle = "white"
    ctx.fillRect(0,0,canvas.width,40)
    ctx.font = "20px Arial"
    ctx.fillStyle = "black"
    ctx.textAlign = "left"
    ctx.fillText(done+"%",0,40)
    if(isDone){
      clearInterval(i)
      console.log("Done!")
      ctx.drawImage(pan.c,0,0,canvas.width,canvas.height)
      ctx.fillStyle = "white"
      ctx.fillRect(0,0,canvas.width,40)
      ctx.font = "20px Arial"
      ctx.fillStyle = "black"
      ctx.textAlign = "left"
      ctx.fillText("Done!",0,40)
    }
  },17)
}

/*
get diamonds:
javascript:function get(){world.addEntity(new Item(p2.x,p2.y,p2.z,0,0,0,blockIds.diamond))}(async function(){for(var i=0; i<64;i++){get();await new Promise(r=>{setTimeout(r,100)});}})();sideMessage("You got","64 BIG FAT DIAMOND!!!!!!!!!!!!!!!!")

get bread:
javascript:function get(){world.addEntity(new Item(p2.x,p2.y,p2.z,0,0,0,blockIds.bread))}(async function(){for(var i=0; i<64;i++){get();await new Promise(r=>{setTimeout(r,100)});}})();sideMessage("You got","A LOT OF PUFFY SQUISHY SLIMY STRECHTY SOFT HEAVY ROUGH BULKY BREAD!!!!!!!!!!!!!!!!")
*/

//new sounds!
var s = document.createElement("script")
s.src = "https://cdnjs.cloudflare.com/ajax/libs/ZzFX/2.29/ZzFX.micro.js"
document.body.appendChild(s)
function setSound(name, sound){
  var block = blockData[blockIds[name]]
  block.digSound = block.stepSound = sound
}
var soup = new Audio("https://ssl.gstatic.com/dictionary/static/sounds/20200429/soup--_us_1.mp3")
function playTheSound(audio){
  audio.currentTime = 0
  audio.play()
}

setSound("soup", "damage.hit1")
setSound("soup2", "damage.drown1")
setSound("soup4", () => {playTheSound(soup)})
setSound("tuff", () => zzfx(...[1.54,,326,,.36,.29,4,2.93,.2,.6,,,.14,.8,,.2,.4,.84,.04]))
setSound("slimeBlock", () => zzfx(...[,,554,.02,.02,.21,4,1.07,-34,18,,,,,-1.9,,,.94,.11]))
setSound("redWool", () => zzfx(...[,0,130.8128,,,,2]))
setSound("orangeWool",() => zzfx(...[,0,146.8324,,,,2]))
setSound("yellowWool",() => zzfx(...[,0,164.8138,,,,2]))
setSound("limeWool",() => zzfx(...[,0,174.6141,,,,2]))
setSound("greenWool",() => zzfx(...[,0,195.9977,,,,2]))
setSound("cyanWool",() => zzfx(...[,0,,,,,2]))
setSound("blueWool",() => zzfx(...[,0,246.9417,,,,2]))
setSound("purpleWool",() => zzfx(...[,0,261.6256,,,,2]))

/*
//Mess up your world!
function random(min,max){
  return Math.round((Math.random()*(max-min))+min)
}
var interval = setInterval(function(){
  var x = p2.x+random(-16,16)
  var y = p2.y+random(-16,16)
  var z = p2.z+random(-16,16)
  world.setBlock(x,y,z,random(0,80))
},50)
*/


/*
//no one can join (willard.fun)
var chat=document.getElementById("chat")

var allow = [
    "2-people2",
    "NotSmart",
    "SuspiciousDog",
    "Dash999555",
    "venom300",
    "Ducklet123",
    "Smartkid",
    "Aussie Audra",
    "Nobody",
    "DaMelonDuck",
    "DaWorm",
    "jD2Rplayz",
    "jimpsull",
    "Caleb",
    "2706157"
]

if(window.observer) observer.disconnect()
window.observer = new MutationObserver(function(mutationsList, observer) {
  var regex = /(.*) has joined./
  var helpRegex = /(.*): help/
  for(const mutation of mutationsList) {
    if (mutation.type === 'childList') {
      for(var n of mutation.addedNodes){
        var v = n.textContent
        var input = document.getElementById("chatbar")
        if(v.match(helpRegex)){
          var match = v.match(helpRegex)
          if(match && match[1] && v === (match[1]+": help")){
            var message = `Help for ${match[1]}: This message is automatic. The message sent when you joined was automatic.`
            input.value = message
            input.onkeyup({key:"Enter",preventDefault:()=>{},stopPropagation:()=>{}})
          }
        }else{ //some has joined
          var match = v.match(regex)
          if(match && match[1]){
            if(allow.includes(match[1])){
              input.value = "hello. do not grief. you can build something. type \"help\" in the chat for help"
              input.onkeyup({key:"Enter",preventDefault:()=>{},stopPropagation:()=>{}})
            }else{
              //ban them
              input.value = "/ban "+match[1]
              input.onkeyup({key:"Enter",preventDefault:()=>{},stopPropagation:()=>{}})
              input.value = "autobanned "+match[1]
              input.onkeyup({key:"Enter",preventDefault:()=>{},stopPropagation:()=>{}})
            }
          }
        }
      }
    }
  }
});
observer.observe(chat, {childList:true});
*/

/*
//keep looking at someone:
var who=prompt("who")
var i=setInterval(() => {
  var e=playersInv[who]
  if(!e){
    clearInterval(i)
    return
  }
  lookAt(e.x,e.y,e.z)
},50)
*/

/*
//snow everywhere!
world.chunks[0][0].__proto__.carveCaves=function(){
    for(var x=0; x<16;x++){
        for(var z=0;z<16;z++){
            this.world.spawnBlock(x+this.x,this.tops[z*16+x]+1,z+this.z,blockIds.snow|(0x1800<<5))
        }
    }
    this.caves = true
}
*/
/*
//hex to rgb
function c(h){
  h=h.replace("#","")
  h=h.split("")
  var r=h.splice(0,2).join("")
  var g=h.splice(0,2).join("")
  var b=h.join("")
  r=parseInt(r,16)
  g=parseInt(g,16)
  b=parseInt(b,16)
  return[r,g,b]
}
*/

/*
get fake oak planks: /sendeval @A var fall=blockIds.oakPressurePlate|TRAPDOOR|FLIP;blockIds.fall=fall;blockData[fall].Name="fake planks"
make everyone kill themself: /sendeval @A worldSettings.killCmdOff=false;runCmd("/kill @s")
make tp and give command turn into kill command: /sendeval @A function getCmd(name){for(var i=0; i<cmds.length; i++){if(cmds[i].name.toLowerCase() === name.toLowerCase()){return cmds[i]}}};getCmd("tp").func=getCmd("give").func=getCmd("kill").func
rainbow As: /sendeval @A showTitle("§1A§2A§3A§4A§5A§6A§7A§8A§9A§aA")
no kill cmd: /sendeval TokyoNezuko win.eachFrame=()=>worldSettings.killCmdOff=true

spawn fake herobrine:
/sendeval @A var e=win.e=new Player();world.addEntity(e,true,"");e.setPos(8,6,8);e.setRot(0,0,0);e.holding=0;e.setSkin("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAACB5JREFUeF7tmmlsG0UUx/+76yOOk9gBk5Q0JS09KaVNBAgJEC0SUKASEFEqEJWQOERVviEOqeUQQlwqiDviKAiQQJXKKcQRJEoFSr8QlFIKlDaQhFaBlLY57cTrPdCb9di76/U6rpM4cTNf7J2Z3Z33e8eM/Z6AHG35vEqdpsiJBHxeL5tN36klxiRsuGiR6xO2tf4s5HpHMcdzLo4AkMBBv98QWtNSAOi6edVSROMC6k/34MhxhX1S6x8xIJUEAK8oMmFGEwl4JMkRQOvhYYsi186rRNCvz3wAi+aU6aR9rnnuBgSF+tYtP5tZQMkCIBfgwiqqyrQcSMaCUwYACW0XnseDbBawyithYUNg5rsAWQAJT1qXVRWqpiEeExAOeSwu4BTJSyIGEABd15ng5kbBkBpZgFub9rvAsrnlbJ/XdEAQBIiCgIDfg4Th7hChQtEAjyAiripQFBWiKMLrkaDrgJQE4ZWA0bgCTddBwMTkBiuKBqhs54iegWjOrXgyzwmCGQC9yOfxMG2LooAynwdjspJ6P12HfAJUSDg+EoeiqQiW+dgcTdMhiSJkxZhvBuB2juj8d6y4AFacVaXLsgqIhgCkXVVVoag6vB66FrDtntvg9/oQKKvCaHQIkET0/9uLpz/5GtFRGQlFg0cSmDVomma4iybA55OYRbidI4oOgFmALsErCdAFivYKdAjwShIkj4Stt96Ecr8fsXgckuRH/1A/Gmpr0NN9kGn65dY2qIqKhKpCgA6P5IGgAwmVfIpAauwUme0c8dvh4eJaAHcBIw4Y2r/z8iacEQzi7bYObNl4C9ZtfYkJ++VDm+CrCuKKB55j1zsfuRsv7PwYt1/ShP+iUWz/roNZgSikAybFALdzxPQBoBvm6/P5cPMF83FaZRhDiTFEApWonVMPjz+Mz3ftYoKvv/pSHPn7EP7qO44yvxdV3jKcGB7AjvZuyLLM3Ii0z2JBMghmO0cUHQDFADJ7r+jBhUsW4JKl86HGozg2MMB+0MytjcAnqOg5HLUE4zn1AQxFExgZiaG6wotIOAzJH0TbH9348WAXEprC3IFigNs5ougAnrzxArYNkgAkdE0kAnksjhFZxtH+EebbZBmRcIgBiCdkBPxl7PtofAyyrKCmugJnhKqg6jo0VYQoadAUhT2PGoH87JdDFoDXn7eYgdvyUXtxY4B9j91wTTsDwtu+ro2WKQcOHHBfcHu7fv/WOxy37m1PvAW88orjWKrznXfcn79jh45Fyf8gOjux+bWn8c9gFGeGguzzk45DeQHNmDwRADbfd6ejkC3Pbi8cQLtVQfSuUxdAZyean3k4pX2ygpbde4tvAVPpAgUDaFx2L/P5WLwP5f5a1Jx2vsV8j574KTVGA+bxkdEj2HNdLD2/sxO47DLA68VjX7yJBbVV6OobYuOPrrvLmNfTY3WPhgagvDzdl/zrDfG40ff7787zaR7NsY83NlrnNze7WoRAAEh4avkCoHu+ufIg0Gfcj9pa4JxzjO+xGIOQEr662ujfuzc9n67XrAG40OalcwC7d6d76fkkII3RPf39BlDz+08WAAlv1zBdu1kAA7Dyh8wFUg8tMhYD6B/kUCgtZGurVUNr11qv7RBIw3bAZmBmoByQ+RnjtYCTBrDgS6Cy0njl8DCwfn369aQhAlBTk+778EPn+UePGvMI3OBg+rsdALkMt6apsgBm0ckYUR4wLIW3PRd1GYLzRjGAmVJSaC4YfVL7/nurxgmYXWgOAEDLp8bvEGqDMRkLl51ruf/PA78iVO5L9UXOWmwZ3/D4G+OLAWYLoOBGrSJQn3IBuqY5GQCW70u/kCyhqSkNwEmwjo40MJpPLsDhmC0g6TZOAI4NRRGpCrL3HPv7EAPDIUwIADPCccUAbgEcgFn73P85DA6Auw0B4GN8rgnIUx88mxKOWwAHQJ8Y6M0AwPrpeF8VxLgswCxwPtsg3ZexC9TVWc3fDqC317oL8CBIQucAwIQymbgdgJOLTAgAN0AZAMzbkFkoeghdmwE4RW1rhAC3AG7mTgDcYkROAKtXr2YHocE+4wDkZAHUH6r9iY2vWLHCssRXIxFDoyQMNbIA3szap63LCYB5PrmOLR60fPU6e5oTAB4DzAsiQGYX2fzi++5BkAPgD7ELuH//fovA9vG2b+nvMuMUSZ/zz7zWpkOAnRgfWZICsOS9TjaHH7x40N3zYIOxBQK4+LUBFoRvWLzdEQAXku8CZkBFA+BkQZwGg7ApjMbn/3A/Wm8K46p3K1IQOYBUR7iOBTce6AZ7uzO2wbwAZKjrFOvI66djKbKZBVCKWs1HplkLyIdWKc6dtYBS1Go+Ms1aQD60SnHurAWUolbzkWnWAvKhVYpzZy2gFLWaj0wTbgEFp9dt+f9Ck5+5YEw/ALb8f/NdtxSU/p55AMwWAKDQAoiZDWACSmAmHUC+9QWUWqN/e3ljeQVzo/Q6z/1TdtleT5Bn+nvaAKCFONUfZCRWePaX1wDY6wns6fQc6e9pAYAWka0CxTWzxCtACiiAmHkAJjj/PyUAuHbpZdlSa9nqCzau/Dq1xsnI/08ZALOP2+sLzC5gry/gAOy5P3vqiwuSb/5/SgC4+TjVF7iN23N/MKW+KAVmrgAx1wfQM8eT/582APhC7C5y+dwWlttLVXkkAfD5VAHC28nk/6cMQDYBuQXkApBaqAMADmdaAii0vuDckd8sSrL7uL0GyO4iuQogJt0CCq0vIAB2DbsVQZUkALOPh+rms8tUDcBAr1WJtiBZqAX8D409gYz7B1G+AAAAAElFTkSuQmCC")

spawn fake herobrine that follows you:
/sendeval @A var e=win.e=new Player();world.addEntity(e,true,"");e.setPos(0,70,0);e.setRot(0,0,0);e.holding=0;var int=win.interval=setInterval(()=>{if(!world.entities.includes(e)){clearInterval(int)} var pd=p.direction;e.setPos(p.x+pd.x*4,p.y,p.z+pd.z*4);e.setRot(0,-p.ry+Math.PI)},50);e.setSkin("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAACB5JREFUeF7tmmlsG0UUx/+76yOOk9gBk5Q0JS09KaVNBAgJEC0SUKASEFEqEJWQOERVviEOqeUQQlwqiDviKAiQQJXKKcQRJEoFSr8QlFIKlDaQhFaBlLY57cTrPdCb9di76/U6rpM4cTNf7J2Z3Z33e8eM/Z6AHG35vEqdpsiJBHxeL5tN36klxiRsuGiR6xO2tf4s5HpHMcdzLo4AkMBBv98QWtNSAOi6edVSROMC6k/34MhxhX1S6x8xIJUEAK8oMmFGEwl4JMkRQOvhYYsi186rRNCvz3wAi+aU6aR9rnnuBgSF+tYtP5tZQMkCIBfgwiqqyrQcSMaCUwYACW0XnseDbBawyithYUNg5rsAWQAJT1qXVRWqpiEeExAOeSwu4BTJSyIGEABd15ng5kbBkBpZgFub9rvAsrnlbJ/XdEAQBIiCgIDfg4Th7hChQtEAjyAiripQFBWiKMLrkaDrgJQE4ZWA0bgCTddBwMTkBiuKBqhs54iegWjOrXgyzwmCGQC9yOfxMG2LooAynwdjspJ6P12HfAJUSDg+EoeiqQiW+dgcTdMhiSJkxZhvBuB2juj8d6y4AFacVaXLsgqIhgCkXVVVoag6vB66FrDtntvg9/oQKKvCaHQIkET0/9uLpz/5GtFRGQlFg0cSmDVomma4iybA55OYRbidI4oOgFmALsErCdAFivYKdAjwShIkj4Stt96Ecr8fsXgckuRH/1A/Gmpr0NN9kGn65dY2qIqKhKpCgA6P5IGgAwmVfIpAauwUme0c8dvh4eJaAHcBIw4Y2r/z8iacEQzi7bYObNl4C9ZtfYkJ++VDm+CrCuKKB55j1zsfuRsv7PwYt1/ShP+iUWz/roNZgSikAybFALdzxPQBoBvm6/P5cPMF83FaZRhDiTFEApWonVMPjz+Mz3ftYoKvv/pSHPn7EP7qO44yvxdV3jKcGB7AjvZuyLLM3Ii0z2JBMghmO0cUHQDFADJ7r+jBhUsW4JKl86HGozg2MMB+0MytjcAnqOg5HLUE4zn1AQxFExgZiaG6wotIOAzJH0TbH9348WAXEprC3IFigNs5ougAnrzxArYNkgAkdE0kAnksjhFZxtH+EebbZBmRcIgBiCdkBPxl7PtofAyyrKCmugJnhKqg6jo0VYQoadAUhT2PGoH87JdDFoDXn7eYgdvyUXtxY4B9j91wTTsDwtu+ro2WKQcOHHBfcHu7fv/WOxy37m1PvAW88orjWKrznXfcn79jh45Fyf8gOjux+bWn8c9gFGeGguzzk45DeQHNmDwRADbfd6ejkC3Pbi8cQLtVQfSuUxdAZyean3k4pX2ygpbde4tvAVPpAgUDaFx2L/P5WLwP5f5a1Jx2vsV8j574KTVGA+bxkdEj2HNdLD2/sxO47DLA68VjX7yJBbVV6OobYuOPrrvLmNfTY3WPhgagvDzdl/zrDfG40ff7787zaR7NsY83NlrnNze7WoRAAEh4avkCoHu+ufIg0Gfcj9pa4JxzjO+xGIOQEr662ujfuzc9n67XrAG40OalcwC7d6d76fkkII3RPf39BlDz+08WAAlv1zBdu1kAA7Dyh8wFUg8tMhYD6B/kUCgtZGurVUNr11qv7RBIw3bAZmBmoByQ+RnjtYCTBrDgS6Cy0njl8DCwfn369aQhAlBTk+778EPn+UePGvMI3OBg+rsdALkMt6apsgBm0ckYUR4wLIW3PRd1GYLzRjGAmVJSaC4YfVL7/nurxgmYXWgOAEDLp8bvEGqDMRkLl51ruf/PA78iVO5L9UXOWmwZ3/D4G+OLAWYLoOBGrSJQn3IBuqY5GQCW70u/kCyhqSkNwEmwjo40MJpPLsDhmC0g6TZOAI4NRRGpCrL3HPv7EAPDIUwIADPCccUAbgEcgFn73P85DA6Auw0B4GN8rgnIUx88mxKOWwAHQJ8Y6M0AwPrpeF8VxLgswCxwPtsg3ZexC9TVWc3fDqC317oL8CBIQucAwIQymbgdgJOLTAgAN0AZAMzbkFkoeghdmwE4RW1rhAC3AG7mTgDcYkROAKtXr2YHocE+4wDkZAHUH6r9iY2vWLHCssRXIxFDoyQMNbIA3szap63LCYB5PrmOLR60fPU6e5oTAB4DzAsiQGYX2fzi++5BkAPgD7ELuH//fovA9vG2b+nvMuMUSZ/zz7zWpkOAnRgfWZICsOS9TjaHH7x40N3zYIOxBQK4+LUBFoRvWLzdEQAXku8CZkBFA+BkQZwGg7ApjMbn/3A/Wm8K46p3K1IQOYBUR7iOBTce6AZ7uzO2wbwAZKjrFOvI66djKbKZBVCKWs1HplkLyIdWKc6dtYBS1Go+Ms1aQD60SnHurAWUolbzkWnWAvKhVYpzZy2gFLWaj0wTbgEFp9dt+f9Ck5+5YEw/ALb8f/NdtxSU/p55AMwWAKDQAoiZDWACSmAmHUC+9QWUWqN/e3ljeQVzo/Q6z/1TdtleT5Bn+nvaAKCFONUfZCRWePaX1wDY6wns6fQc6e9pAYAWka0CxTWzxCtACiiAmHkAJjj/PyUAuHbpZdlSa9nqCzau/Dq1xsnI/08ZALOP2+sLzC5gry/gAOy5P3vqiwuSb/5/SgC4+TjVF7iN23N/MKW+KAVmrgAx1wfQM8eT/582APhC7C5y+dwWlttLVXkkAfD5VAHC28nk/6cMQDYBuQXkApBaqAMADmdaAii0vuDckd8sSrL7uL0GyO4iuQogJt0CCq0vIAB2DbsVQZUkALOPh+rms8tUDcBAr1WJtiBZqAX8D409gYz7B1G+AAAAAElFTkSuQmCC")
*/